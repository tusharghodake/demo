export const USERS = [
{
    firstName: 'Sara',
    lastName: 'Barnett',
    level: 'Beginner',
    jobTitle: 'UI Designer',
    age:'18'
  },
  {
    firstName: 'Gabriel',
    lastName: 'Green',
    level: 'Expert',
    jobTitle: 'JS Developer',
    age:'25'
  },
  {
    firstName: 'Janet',
    lastName: 'Cox',
    level: 'Beginner',
    jobTitle: 'Front-end Developer',
    age:'45'
  },
  {
    firstName: 'Frank',
    lastName: 'Murray',
    level: 'Expert',
    jobTitle: 'Entrepreenur',
    age:'67'
  },
  {
    firstName: 'Olivia',
    lastName: 'Peterson',
    level: 'Beginner',
    jobTitle: 'Blogger',
    age:'37'
  },
  {
    firstName: 'Tyler',
    lastName: 'Rice',
    level: 'Expert',
    jobTitle: 'Accountant',
    age:'28'
  }
];
